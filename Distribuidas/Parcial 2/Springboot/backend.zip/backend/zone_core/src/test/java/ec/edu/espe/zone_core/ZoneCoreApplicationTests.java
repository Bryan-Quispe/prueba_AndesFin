package ec.edu.espe.zone_core;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZoneCoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
