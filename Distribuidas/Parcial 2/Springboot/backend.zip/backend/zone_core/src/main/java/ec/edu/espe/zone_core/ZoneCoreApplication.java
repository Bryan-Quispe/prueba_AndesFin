package ec.edu.espe.zone_core;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZoneCoreApplication {

	public static void main(String[] args) {
        SpringApplication.run(ZoneCoreApplication.class, args);
    }

}
